from django.apps import AppConfig


class AdminzoneConfig(AppConfig):
    name = 'adminzone'
