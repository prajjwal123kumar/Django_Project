from django.apps import AppConfig


class GenzoneConfig(AppConfig):
    name = 'genzone'
